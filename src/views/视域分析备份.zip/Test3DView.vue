<script setup>
import { onMounted, onBeforeUnmount, ref } from 'vue'
import * as Cesium from 'cesium'
import 'cesium/Build/Cesium/Widgets/widgets.css'
import axios from 'axios'

// Cesium Ion token
Cesium.Ion.defaultAccessToken =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJlYmZmMWRmOS0yY2RlLTQ0NjMtOGE5Yy02OWM3MWM3MTc2ZGUiLCJpZCI6MzkzMjQ1LCJpYXQiOjE3NzE4MzI4NDV9.gXXxAwMo31mBsVDlfvQC4lfvX0gQo_6xZvysYzmq5r4'

// API基础地址
const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api'

const mapContainer = ref(null)
let viewer = null
let buildingsDataSource = null
let facilitiesLoaded = false

// 设施类型颜色映射
const categoryColors = {
  hospital: Cesium.Color.fromCssColorString('#ef4444'), // 红色
  school: Cesium.Color.fromCssColorString('#10b981'), // 绿色
  shelter: Cesium.Color.fromCssColorString('#f59e0b'), // 橙色
  resident: Cesium.Color.fromCssColorString('#22d3ee'), // 青色
  commercial: Cesium.Color.fromCssColorString('#eab308'), // 黄色
  other: Cesium.Color.fromCssColorString('#9333ea'), // 紫色
}

// 设施类型高度映射（用于面数据拉伸）
const categoryHeights = {
  hospital: 60,
  school: 35,
  shelter: 40,
  resident: 30,
  commercial: 70,
  other: 40,
}

// 热力图相关变量
let heatmapDataSource = null
const heatmapVisible = ref(false)

// 视域分析相关变量
const viewshedActive = ref(false)
let viewshedObserverPosition = null
let viewshedRadius = 2000 // 视域半径（米）
const viewshedHeight = ref(30) // 观察高度（米），默认30m，可调

function normalizeCategory(rawType) {
  const t = (rawType || '').toLowerCase()
  if (t.includes('hospital') || t.includes('医院') || t.includes('医疗')) return 'hospital'
  if (t.includes('school') || t.includes('学校') || t.includes('教育') || t.includes('小学') || t.includes('中学')) return 'school'
  if (t.includes('shelter') || t.includes('避难') || t.includes('应急')) return 'shelter'
  if (t.includes('居民') || t.includes('小区') || t.includes('社区') || t.includes('住宅')) return 'resident'
  if (t.includes('商业') || t.includes('商场') || t.includes('超市') || t.includes('mall') || t.includes('购物')) return 'commercial'
  return 'other'
}

// 添加设施点
function addFacilityPoint(f) {
  if (!viewer) return
  if (f.lon == null || f.lat == null) return

  const category = normalizeCategory(f.type)
  const color = categoryColors[category] || categoryColors.other

  const entity = viewer.entities.add({
    position: Cesium.Cartesian3.fromDegrees(f.lon, f.lat, 15),
    point: {
      pixelSize: 12,
      color: color.withAlpha(0.9),
      outlineColor: Cesium.Color.WHITE,
      outlineWidth: 2,
      heightReference: Cesium.HeightReference.RELATIVE_TO_GROUND,
      disableDepthTestDistance: Number.POSITIVE_INFINITY,
    },
    label: {
      text: f.name || '',
      font: '12pt sans-serif',
      fillColor: Cesium.Color.WHITE,
      outlineColor: Cesium.Color.BLACK,
      outlineWidth: 2,
      verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
      pixelOffset: new Cesium.Cartesian2(0, -15),
      show: false,
    },
    name: f.name || '设施',
    description: `
      <table style="width:100%;border-collapse:collapse;">
        <tr><td style="padding:5px;border:1px solid #ddd;font-weight:bold;">名称</td><td style="padding:5px;border:1px solid #ddd;">${f.name || ''}</td></tr>
        <tr><td style="padding:5px;border:1px solid #ddd;font-weight:bold;">类型</td><td style="padding:5px;border:1px solid #ddd;">${f.type || ''}</td></tr>
        <tr><td style="padding:5px;border:1px solid #ddd;font-weight:bold;">经度</td><td style="padding:5px;border:1px solid #ddd;">${f.lon}</td></tr>
        <tr><td style="padding:5px;border:1px solid #ddd;font-weight:bold;">纬度</td><td style="padding:5px;border:1px solid #ddd;">${f.lat}</td></tr>
      </table>
    `,
    properties: {
      type: f.type || '',
      category,
    },
  })

  return entity
}

// 加载后端设施数据
async function loadFacilities() {
  if (!viewer || facilitiesLoaded) return

  try {
    const res = await axios.get(`${API_BASE}/facilities`)
    const facilities = res.data || []

    facilities.forEach((f) => {
      addFacilityPoint(f)
    })

    facilitiesLoaded = true
    console.log(`已加载 ${facilities.length} 个设施点`)
  } catch (err) {
    console.error('加载设施数据失败', err)
  }
}

// GCJ-02 转 WGS84 坐标转换（中国地图数据常用）
function gcj02ToWgs84(lng, lat) {
  const a = 6378245.0
  const ee = 0.00669342162296594323
  const pi = 3.14159265358979324

  if (outOfChina(lng, lat)) return { lng, lat }

  let dlat = transformLat(lng - 105.0, lat - 35.0)
  let dlng = transformLng(lng - 105.0, lat - 35.0)
  const radlat = (lat / 180.0) * pi
  const magic = Math.sin(radlat)
  const magic2 = 1 - ee * magic * magic
  const sqrtmagic = Math.sqrt(magic2)

  dlat = (dlat * 180.0) / (((a * (1 - ee)) / (magic2 * sqrtmagic)) * pi)
  dlng = (dlng * 180.0) / ((a / sqrtmagic) * Math.cos(radlat) * pi)

  const mglat = lat + dlat
  const mglng = lng + dlng

  return { lng: lng * 2 - mglng, lat: lat * 2 - mglat }
}

function outOfChina(lng, lat) {
  return lng < 72.004 || lng > 137.8347 || lat < 0.8293 || lat > 55.8271
}

function transformLat(lng, lat) {
  const pi = 3.14159265358979324
  let ret = -100.0 + 2.0 * lng + 3.0 * lat + 0.2 * lat * lat + 0.1 * lng * lat + 0.2 * Math.sqrt(Math.abs(lng))
  ret += ((20.0 * Math.sin(6.0 * lng * pi) + 20.0 * Math.sin(2.0 * lng * pi)) * 2.0) / 3.0
  ret += ((20.0 * Math.sin(lat * pi) + 40.0 * Math.sin((lat / 3.0) * pi)) * 2.0) / 3.0
  ret += ((160.0 * Math.sin((lat / 12.0) * pi) + 320 * Math.sin((lat * pi) / 30.0)) * 2.0) / 3.0
  return ret
}

function transformLng(lng, lat) {
  const pi = 3.14159265358979324
  let ret = 300.0 + lng + 2.0 * lat + 0.1 * lng * lng + 0.1 * lng * lat + 0.1 * Math.sqrt(Math.abs(lng))
  ret += ((20.0 * Math.sin(6.0 * lng * pi) + 20.0 * Math.sin(2.0 * lng * pi)) * 2.0) / 3.0
  ret += ((20.0 * Math.sin(lng * pi) + 40.0 * Math.sin((lng / 3.0) * pi)) * 2.0) / 3.0
  ret += ((150.0 * Math.sin((lng / 12.0) * pi) + 300.0 * Math.sin((lng / 30.0) * pi)) * 2.0) / 3.0
  return ret
}

// 6类设施GeoJSON配置
const buildingFiles = [
  { name: '教育服务', category: 'school', url: '/data/教育服务.geojson' },
  { name: '居民小区', category: 'resident', url: '/data/居民小区.geojson' },
  { name: '其他设施', category: 'other', url: '/data/其他设施1.geojson' },
  { name: '商业商场', category: 'commercial', url: '/data/商业商场.geojson' },
  { name: '医疗卫生', category: 'hospital', url: '/data/医疗卫生.geojson' },
  { name: '应急避难', category: 'shelter', url: '/data/应急避难.geojson' },
]

// 加载所有GeoJSON面数据并拉伸为3D建筑
async function loadAllBuildings() {
  if (!viewer) return

  let totalLoaded = 0

  for (const file of buildingFiles) {
    try {
      const color = categoryColors[file.category] || categoryColors.other
      const height = categoryHeights[file.category] || 25

      const dataSource = await Cesium.GeoJsonDataSource.load(file.url, {
        stroke: Cesium.Color.TRANSPARENT,
        fill: Cesium.Color.TRANSPARENT,
        strokeWidth: 0,
      })

      await viewer.dataSources.add(dataSource)

      // 遍历实体并拉伸
      let successCount = 0
      let failCount = 0
      dataSource.entities.values.forEach((entity, index) => {
        if (!entity.polygon) {
          console.warn(`${file.name} 第${index}个实体没有polygon`)
          return
        }

        try {
          // 检查多边形是否有效
          const hierarchy = entity.polygon.hierarchy?.getValue?.()
          if (!hierarchy || !hierarchy.positions || hierarchy.positions.length < 3) {
            console.warn(`${file.name} 第${index}个实体多边形顶点不足`)
            failCount++
            return
          }

          // 转换坐标：GCJ-02 -> WGS84
          const newPositions = hierarchy.positions.map((cartesian) => {
            const cartographic = Cesium.Cartographic.fromCartesian(cartesian)
            const lng = Cesium.Math.toDegrees(cartographic.longitude)
            const lat = Cesium.Math.toDegrees(cartographic.latitude)
            const wgs84 = gcj02ToWgs84(lng, lat)
            return Cesium.Cartesian3.fromDegrees(wgs84.lng, wgs84.lat, 0)
          })
          entity.polygon.hierarchy = new Cesium.PolygonHierarchy(newPositions)

          // 设置拉伸样式 - 贴地显示
          entity.polygon.extrudedHeight = height
          entity.polygon.height = 0
          entity.polygon.heightReference = Cesium.HeightReference.RELATIVE_TO_GROUND
          entity.polygon.extrudedHeightReference = Cesium.HeightReference.RELATIVE_TO_GROUND
          entity.polygon.material = color.withAlpha(0.55)
          entity.polygon.outline = true
          entity.polygon.outlineColor = color.withAlpha(0.85)
          entity.polygon.outlineWidth = 1
          entity.polygon.classificationType = Cesium.ClassificationType.BOTH

          // 添加属性标记
          entity.properties = entity.properties || {}
          if (!entity.properties.category) {
            entity.properties.category = file.category
          }
          successCount++
        } catch (err) {
          console.error(`${file.name} 第${index}个实体处理失败:`, err.message)
          failCount++
        }
      })

      console.log(`${file.name}: 成功${successCount}个, 失败${failCount}个`)

      totalLoaded += dataSource.entities.values.length
      console.log(`加载 ${file.name}: ${dataSource.entities.values.length} 个面`)
    } catch (err) {
      console.warn(`加载 ${file.name} 失败:`, err.message)
    }
  }

  console.log(`共加载 ${totalLoaded} 个3D建筑面`)
}

// 初始化Cesium场景
async function initCesium() {
  if (!mapContainer.value) return

  // 确保容器有尺寸
  const container = mapContainer.value
  if (container.clientWidth === 0 || container.clientHeight === 0) {
    console.warn('Container size is 0, forcing min size')
    container.style.width = '100%'
    container.style.height = '100%'
    container.style.minWidth = '800px'
    container.style.minHeight = '600px'
  }

  // 等待一下确保DOM渲染完成
  await new Promise(resolve => setTimeout(resolve, 100))

  viewer = new Cesium.Viewer(mapContainer.value, {
    timeline: false,
    animation: false,
    geocoder: false,
    homeButton: false,
    sceneModePicker: false,
    baseLayerPicker: false,
    navigationHelpButton: false,
    fullscreenButton: false,
    // 使用世界地形
    terrainProvider: await Cesium.createWorldTerrainAsync(),
    // 使用Cesium默认底图（Bing Maps卫星影像）
    useDefaultRenderLoop: true,
  })

  // 禁用渲染错误弹窗
  viewer.cesiumWidget.showRenderLoopErrors = false

  // 内存缓存优化
  viewer.scene.globe.tileCacheSize = 200

  // 绑定点击事件（用于视域分析）
  viewer.screenSpaceEventHandler.setInputAction(handleMapClick, Cesium.ScreenSpaceEventType.LEFT_CLICK)

  // 飞到淄博张店附近上空 - 与MapView一致的视角
  viewer.camera.flyTo({
    destination: Cesium.Cartesian3.fromDegrees(118.010, 36.920, 9000),
    orientation: {
      heading: Cesium.Math.toRadians(-180),
      pitch: Cesium.Math.toRadians(-40),
      roll: 0,
    },
    duration: 1.5,
  })

  // 启用深度测试
  viewer.scene.globe.depthTestAgainstTerrain = true

  // 加载设施数据
  await loadFacilities()

  // 加载6类3D建筑面数据
  await loadAllBuildings()
}

// 重置视角
function resetView() {
  if (!viewer) return
  viewer.camera.flyTo({
    destination: Cesium.Cartesian3.fromDegrees(118.060, 36.810, 8000),
    orientation: {
      heading: Cesium.Math.toRadians(0),
      pitch: Cesium.Math.toRadians(-50),
      roll: 0,
    },
    duration: 1.5,
  })
}

onMounted(() => {
  initCesium()
})

onBeforeUnmount(() => {
  if (viewer) {
    viewer.destroy()
    viewer = null
  }
})

// 热力图显示/隐藏控制
function setHeatmapVisible(visible) {
  if (visible) {
    loadHeatmap()
  } else if (heatmapDataSource) {
    heatmapDataSource.show = false
  }
}

// 切换热力图
function toggleHeatmap() {
  heatmapVisible.value = !heatmapVisible.value
  setHeatmapVisible(heatmapVisible.value)
}

// 加载热力图
async function loadHeatmap() {
  if (!viewer) return
  
  try {
    // 清除之前的热力图数据
    if (heatmapDataSource) {
      try {
        const dataSources = viewer.dataSources
        let exists = false
        for (let i = 0; i < dataSources.length; i++) {
          if (dataSources.get(i) === heatmapDataSource) {
            exists = true
            break
          }
        }
        if (exists) {
          dataSources.remove(heatmapDataSource, true)
        }
      } catch (e) {
        console.log('清理热力图数据源:', e?.message || '未知错误')
      }
      heatmapDataSource = null
    }
    
    console.log('开始构建网格热力图')
    
    // 获取设施数据
    const res = await axios.get(`${API_BASE}/facilities`)
    const facilities = res.data || []
    
    if (!Array.isArray(facilities) || facilities.length === 0) {
      console.error('没有设施数据')
      return
    }
    
    // 创建热力图数据源
    heatmapDataSource = new Cesium.CustomDataSource('heatmap')
    
    // 定义网格大小：根据经纬度计算（约1km）
    const gridSize = 0.009
    const gridStats = new Map()
    
    // 遍历设施点，计算每个网格的设施数量
    facilities.forEach((facility) => {
      const lon = facility.longitude ?? facility.lon
      const lat = facility.latitude ?? facility.lat
      
      if (!lon || !lat) return
      
      // 计算网格坐标
      const gridX = Math.floor(lon / gridSize) * gridSize
      const gridY = Math.floor(lat / gridSize) * gridSize
      const gridKey = `${gridX.toFixed(4)},${gridY.toFixed(4)}`
      
      if (!gridStats.has(gridKey)) {
        gridStats.set(gridKey, {
          minX: gridX,
          minY: gridY,
          maxX: gridX + gridSize,
          maxY: gridY + gridSize,
          count: 0,
          facilities: []
        })
      }
      
      const grid = gridStats.get(gridKey)
      grid.count++
      grid.facilities.push(facility)
    })
    
    const sortedGrids = Array.from(gridStats.values()).sort((a, b) => b.count - a.count)
    
    if (sortedGrids.length === 0) {
      console.error('没有有效的网格数据')
      return
    }
    
    const maxCount = sortedGrids[0].count
    const minCount = sortedGrids[sortedGrids.length - 1].count
    
    // 定义颜色等级
    const colorLevels = [
      { threshold: 0.83, color: '#a50026' },
      { threshold: 0.67, color: '#ff7f00' },
      { threshold: 0.50, color: '#ffff00' },
      { threshold: 0.33, color: '#00ff00' },
      { threshold: 0.17, color: '#00bfff' },
      { threshold: 0.0,  color: '#0000ff' },
    ]
    
    // 为每个网格创建矩形
    sortedGrids.forEach((grid) => {
      const normalizedCount = (grid.count - minCount) / (maxCount - minCount || 1)
      let color = '#0000ff'
      
      for (const level of colorLevels) {
        if (normalizedCount >= level.threshold) {
          color = level.color
          break
        }
      }
      
      heatmapDataSource.entities.add({
        polygon: {
          hierarchy: Cesium.Cartesian3.fromDegreesArray([
            grid.minX, grid.minY,
            grid.maxX, grid.minY,
            grid.maxX, grid.maxY,
            grid.minX, grid.maxY
          ]),
          material: Cesium.Color.fromCssColorString(color).withAlpha(0.55),
          outline: true,
          outlineColor: Cesium.Color.WHITE.withAlpha(0.3),
          outlineWidth: 1,
          height: 0,
          heightReference: Cesium.HeightReference.RELATIVE_TO_GROUND,
          classificationType: Cesium.ClassificationType.BOTH
        },
        properties: {
          gridData: grid,
          type: 'grid'
        }
      })
    })
    
    // 添加数据源
    let alreadyAdded = false
    for (let i = 0; i < viewer.dataSources.length; i++) {
      if (viewer.dataSources.get(i) === heatmapDataSource) {
        alreadyAdded = true
        break
      }
    }
    if (!alreadyAdded) {
      await viewer.dataSources.add(heatmapDataSource)
    }
    
    // 将热力图置于底层
    try {
      if (heatmapDataSource) {
        viewer.dataSources.lower(heatmapDataSource)
      }
    } catch (e) {
      console.log('调整热力图层级:', e?.message || '未知错误')
    }
    
    console.log(`网格热力图加载完成，共创建 ${sortedGrids.length} 个网格`)
  } catch (err) {
    console.error('加载网格热力图失败', err)
  }
}

// 视域分析控制
function setViewshedVisible(visible) {
  viewshedActive.value = visible
  
  if (!visible) {
    clearViewshed()
    return
  }
  
  // 如果已经有观察点，重新计算视域
  if (viewshedObserverPosition) {
    calculateViewshed(viewshedObserverPosition)
  }
}

// 切换视域分析
function toggleViewshed() {
  viewshedActive.value = !viewshedActive.value
  setViewshedVisible(viewshedActive.value)
}

// 清除视域分析结果
function clearViewshed() {
  if (!viewer) return
  
  const entitiesToRemove = viewer.entities.values.filter(e => {
    const type = e.properties?.type?.getValue?.()
    return type === 'viewshedVisible' || type === 'viewshedObserver'
  })
  
  entitiesToRemove.forEach(e => viewer.entities.remove(e))
}

// ==================== 坐标转换工具（统一简化投影）====================
// 经纬度转平面米制坐标（相对于中心点）
function lonLatToMeters(lon, lat, centerLon, centerLat) {
  const toRad = Math.PI / 180
  // 在淄博纬度(~36度)处，1度经度≈111320*cos(36°)≈90000米
  // 1度纬度≈111000米
  const metersPerLon = 111320 * Math.cos(centerLat * toRad)
  const metersPerLat = 111000
  
  return { 
    x: (lon - centerLon) * metersPerLon, 
    y: (lat - centerLat) * metersPerLat 
  }
}

// 平面坐标转回经纬度（Web Mercator反向投影）
function metersToLonLat(x, y, observerLon, observerLat) {
  // 使用 Cesium WebMercatorProjection 保持一致性
  const projection = new Cesium.WebMercatorProjection()
  
  // 观察点投影
  const observerCartographic = Cesium.Cartographic.fromDegrees(observerLon, observerLat)
  const observerMercator = projection.project(observerCartographic)
  
  // 计算目标点的 Web Mercator 坐标（局部坐标 + 观察点坐标）
  const targetMercator = {
    x: observerMercator.x + x,
    y: observerMercator.y + y
  }
  
  // 反向投影回经纬度
  const targetCartographic = projection.unproject(targetMercator)
  
  return {
    lon: Cesium.Math.toDegrees(targetCartographic.longitude),
    lat: Cesium.Math.toDegrees(targetCartographic.latitude)
  }
}

// 判断点是否在多边形内（Ray Casting算法，平面坐标）
function isPointInPolygon(point, polygon) {
  let inside = false
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x, yi = polygon[i].y
    const xj = polygon[j].x, yj = polygon[j].y
    
    const intersect = ((yi > point.y) !== (yj > point.y)) &&
        (point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi)
    if (intersect) inside = !inside
  }
  return inside
}

// 边界框快速检测
function isRayIntersectingBounds(observer, angle, bounds) {
  // 简化的边界框检测：检查射线方向是否与边界框相交
  // 这里使用保守估计，只要射线方向指向边界框区域就返回true
  const dx = Math.cos(angle)
  const dy = Math.sin(angle)
  
  // 计算边界框中心方向
  const centerX = (bounds.minX + bounds.maxX) / 2
  const centerY = (bounds.minY + bounds.maxY) / 2
  const toCenterX = centerX - observer.x
  const toCenterY = centerY - observer.y
  
  // 计算角度差
  const angleToCenter = Math.atan2(toCenterY, toCenterX)
  const angleDiff = Math.abs(angle - angleToCenter)
  const normalizedDiff = Math.min(angleDiff, 2 * Math.PI - angleDiff)
  
  // 如果射线方向与指向边界框中心的方向偏差小于90度，进一步检测
  if (normalizedDiff > Math.PI / 2) return false
  
  // 计算到边界框的距离
  const distToCenter = Math.sqrt(toCenterX * toCenterX + toCenterY * toCenterY)
  const boxRadius = Math.sqrt(
    Math.pow(bounds.maxX - bounds.minX, 2) + 
    Math.pow(bounds.maxY - bounds.minY, 2)
  ) / 2
  
  return distToCenter < (2000 + boxRadius) // 在最大半径范围内
}

// ==================== 视域分析核心算法（平面几何版）====================

/**
 * 计算射线与AABB包围盒的相交距离
 * 射线: P(t) = O + t*D, t >= 0
 * AABB: [minX, maxX] × [minY, maxY]
 * 返回射线进入包围盒的距离 tEnter，如果相交
 */
function rayBoxIntersection(ox, oy, dx, dy, minX, minY, maxX, maxY) {
  let tMin = -Infinity
  let tMax = Infinity

  // X轴方向
  if (Math.abs(dx) < 0.00001) {
    // 射线平行于X轴
    if (ox < minX || ox > maxX) return null
  } else {
    const t1 = (minX - ox) / dx
    const t2 = (maxX - ox) / dx
    tMin = Math.max(tMin, Math.min(t1, t2))
    tMax = Math.min(tMax, Math.max(t1, t2))
  }

  // Y轴方向
  if (Math.abs(dy) < 0.00001) {
    // 射线平行于Y轴
    if (oy < minY || oy > maxY) return null
  } else {
    const t1 = (minY - oy) / dy
    const t2 = (maxY - oy) / dy
    tMin = Math.max(tMin, Math.min(t1, t2))
    tMax = Math.min(tMax, Math.max(t1, t2))
  }

  // 相交条件: tMax >= tMin 且 tMax > 0 (射线前方有交点)
  if (tMax >= tMin && tMax > 0) {
    // 返回进入距离 (tMin > 0 ? tMin : 0)
    // 如果观察点在包围盒内部，tMin可能是负数，此时返回0
    const enterDist = tMin > 0 ? tMin : 0
    return { enter: enterDist, exit: tMax }
  }

  return null
}

/**
 * 计算射线与线段的交点
 * 射线: P = O + t*D
 * 线段: P = A + u(B-A)
 */
function getIntersection(ox, oy, dx, dy, x1, y1, x2, y2) {
  const x12 = x1 - x2
  const y12 = y1 - y2
  const det = -dx * y12 + dy * x12

  if (Math.abs(det) < 0.00001) return null // 平行

  const t = ((ox - x2) * y12 - (oy - y2) * x12) / det
  const u = (-(ox - x2) * dy + (oy - y2) * dx) / det

  // t > 0 表示在射线前方，0 <= u <= 1 表示在线段上
  if (t > 0 && u >= 0 && u <= 1) {
    return { dist: t, x: ox + t * dx, y: oy + t * dy }
  }
  return null
}

/**
 * 核心射线投射函数（平面几何版）
 * @param {number} angle - 射线角度（弧度）
 * @param {Object} observer - 观察点 { x: 0, y: 0, height: 18 }
 * @param {Array} buildings - 建筑物列表 (已转换为平面坐标)
 * @param {number} maxRadius - 最大半径
 */
function castRay(angle, observer, buildings, maxRadius, debug = false) {
  const dirX = Math.cos(angle)
  const dirY = Math.sin(angle)

  // 收集所有有效交点：{dist, height, buildingId}
  const intersections = []

  for (const building of buildings) {
    const height = Number(building.height)
    const bounds = building.bounds

    // 【粗筛】快速距离检查：计算建筑中心到观察点的距离
    const centerX = (bounds.minX + bounds.maxX) / 2
    const centerY = (bounds.minY + bounds.maxY) / 2
    const centerDist = Math.sqrt(centerX * centerX + centerY * centerY)
    const boxRadius = Math.sqrt(
      Math.pow(bounds.maxX - bounds.minX, 2) +
      Math.pow(bounds.maxY - bounds.minY, 2)
    ) / 2

    // 如果建筑中心太远（超过 maxRadius + 建筑半径），直接跳过
    if (centerDist > maxRadius + boxRadius) {
      continue
    }

    // 【精算】射线与包围盒相交检测
    const boxHit = rayBoxIntersection(
      observer.x, observer.y, dirX, dirY,
      bounds.minX, bounds.minY, bounds.maxX, bounds.maxY
    )

    if (boxHit && boxHit.enter > 0 && boxHit.enter <= maxRadius) {
      intersections.push({
        dist: boxHit.enter,
        height: height,
        buildingId: building.id
      })
      if (debug && boxHit.enter < 500) {
        console.log(`  包围盒相交: 距离${boxHit.enter.toFixed(1)}m, 建筑高${height}m, 尺寸${(bounds.maxX-bounds.minX).toFixed(0)}×${(bounds.maxY-bounds.minY).toFixed(0)}m`)
      }
    }
  }

  // 按进入距离排序
  intersections.sort((a, b) => a.dist - b.dist)

  // 找到最近的能挡住视线的交点
  let closestBlockDist = maxRadius
  let isBlocked = false
  let hitBuildingHeight = null

  for (const hit of intersections) {
    // 在距离 hit.dist 处，视线高度 = 观察点高度（假设水平视线）
    const viewHeightAtDist = observer.height

    // 如果建筑高度 > 视线高度，则被挡住
    if (hit.height > viewHeightAtDist) {
      closestBlockDist = hit.dist
      isBlocked = true
      hitBuildingHeight = hit.height
      break // 找到最近的遮挡就停止
    }
    // 如果挡不住，继续检查后面的交点
  }

  if (debug) {
    if (isBlocked) {
      console.log(`  → 遮挡! 距离${closestBlockDist.toFixed(1)}m, 建筑高${hitBuildingHeight}m > 视线高${observer.height.toFixed(0)}m`)
    } else if (intersections.length > 0) {
      console.log(`  可越过所有建筑, 最近交点${intersections[0].dist.toFixed(0)}m, 但建筑高${intersections[0].height}m <= 视线高${observer.height.toFixed(0)}m`)
    } else {
      console.log(`  无交点, 自由视域${maxRadius}m`)
    }
  }

  return {
    dist: closestBlockDist,
    blocked: isBlocked,
    x: observer.x + dirX * closestBlockDist,
    y: observer.y + dirY * closestBlockDist
  }
}

// 计算视域分析（基于墨卡托投影平面坐标）
async function calculateViewshed(observerPos) {
  if (!viewer) return
  
  viewshedObserverPosition = observerPos
  
  // 如果视域分析未激活，不计算
  if (!viewshedActive.value) return
  
  // 清除之前的视域结果
  clearViewshed()
  
  const { lon, lat } = observerPos
  const radius = viewshedRadius
  const observerHeight = viewshedHeight.value
  
  // 获取观察点地形高度
  const observerCart = Cesium.Cartesian3.fromDegrees(lon, lat)
  const observerCartographic = Cesium.Cartographic.fromCartesian(observerCart)
  const terrainHeight = await viewer.scene.globe.getHeight(observerCartographic) || 0
  const observerEyeHeight = terrainHeight + observerHeight
  
  // 添加观察点（黄色标记）
  viewer.entities.add({
    position: Cesium.Cartesian3.fromDegrees(lon, lat, observerEyeHeight),
    point: {
      pixelSize: 20,
      color: Cesium.Color.YELLOW,
      outlineColor: Cesium.Color.BLACK,
      outlineWidth: 2,
    },
    properties: {
      type: 'viewshedObserver'
    }
  })
  
  console.log(`视域分析开始: 观察点(${lon.toFixed(4)}, ${lat.toFixed(4)}), 高度${observerHeight}m`)
  
  // ==================== 步骤1：Cesium WebMercator投影坐标转换 ====================
  // 使用 Cesium 标准的 WebMercatorProjection
  const projection = new Cesium.WebMercatorProjection()
  
  // 观察点转为 Web Mercator
  const obsCarto = Cesium.Cartographic.fromDegrees(lon, lat)
  const observerMercator = projection.project(obsCarto)
  console.log(`Observer Mercator: x=${observerMercator.x.toFixed(0)}, y=${observerMercator.y.toFixed(0)}`)
  console.log(`Observer Local X, Y: (0, 0)`)
  
  const buildings = []
  let entityCount = 0
  let debugBuildings = []
  
  const dataSourceCount = viewer.dataSources.length
  for (let dsIdx = 0; dsIdx < dataSourceCount; dsIdx++) {
    const dataSource = viewer.dataSources.get(dsIdx)
    for (const entity of dataSource.entities.values) {
      if (!entity.polygon) continue
      
      // 获取高度
      let height = 30
      const category = entity.properties?.category?.getValue?.() || 
                       dataSource.name?.toLowerCase?.() || 'other'
      if (category && categoryHeights[category]) {
        height = categoryHeights[category]
      }
      
      entityCount++
      
      try {
        const hierarchy = entity.polygon.hierarchy?.getValue?.(Cesium.JulianDate.now())
        if (!hierarchy || !hierarchy.positions || hierarchy.positions.length < 3) continue
        
        // 转换多边形顶点为相对于观察点的局部坐标
        const polygon = []
        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity
        let firstVertexRealPos = null
        let firstVertexMercator = null
        
        for (let i = 0; i < hierarchy.positions.length; i++) {
          const pos = hierarchy.positions[i]
          
          // 获取经纬度
          const carto = Cesium.Cartographic.fromCartesian(pos)
          const pLon = Cesium.Math.toDegrees(carto.longitude)
          const pLat = Cesium.Math.toDegrees(carto.latitude)
          
          // 投影到 Web Mercator
          const posCartographic = Cesium.Cartographic.fromDegrees(pLon, pLat)
          const posMercator = projection.project(posCartographic)
          
          // 保存第一个顶点的原始位置用于调试
          if (i === 0) {
            firstVertexRealPos = { lon: pLon, lat: pLat }
            firstVertexMercator = { x: posMercator.x, y: posMercator.y }
          }
          
          // 计算相对于观察点的局部坐标（关键！）
          const relativeX = posMercator.x - observerMercator.x
          const relativeY = posMercator.y - observerMercator.y
          
          polygon.push({ x: relativeX, y: relativeY })
          
          minX = Math.min(minX, relativeX)
          maxX = Math.max(maxX, relativeX)
          minY = Math.min(minY, relativeY)
          maxY = Math.max(maxY, relativeY)
        }
        
        if (polygon.length >= 3) {
          const building = {
            id: entity.id,
            height: height,
            polygon: polygon,
            bounds: { minX, maxX, minY, maxY },
            firstVertexRealPos: firstVertexRealPos,
            firstVertexMercator: firstVertexMercator
          }
          buildings.push(building)
          
          // 收集前3个用于调试输出
          if (debugBuildings.length < 3) {
            const relativeX = polygon[0].x
            const relativeY = polygon[0].y
            debugBuildings.push({
              index: debugBuildings.length,
              mercatorX: firstVertexMercator.x.toFixed(0),
              mercatorY: firstVertexMercator.y.toFixed(0),
              relativeX: relativeX.toFixed(0),
              relativeY: relativeY.toFixed(0),
              realLon: firstVertexRealPos.lon.toFixed(6),
              realLat: firstVertexRealPos.lat.toFixed(6)
            })
          }
        }
      } catch (e) {
        // 跳过
      }
    }
  }
  
  console.log(`提取了 ${buildings.length} 个建筑物`)
  
  // 调试输出：建筑物坐标
  debugBuildings.forEach(b => {
    console.log(`Building ${b.index} Mercator: (${b.mercatorX}, ${b.mercatorY}) -> Relative: (${b.relativeX}, ${b.relativeY}), Real: (${b.realLon}, ${b.realLat})`)
  })
  
  // ==================== 步骤2：720方向射线投射（每0.5度一根，更平滑）====================
  const directions = 720  // 增加密度：0.5度一根
  const visibleBoundaries = []
  
  // 观察点平面坐标（中心点，所以是0,0），高度为纯观察高度（不含地形）
  const observer = { x: 0, y: 0, height: observerHeight }
  
  for (let d = 0; d < directions; d++) {
    const angle = (d / directions) * Math.PI * 2
    
    // 前20条射线启用调试模式
    const debug = d < 20
    const result = castRay(angle, observer, buildings, radius, debug)
    
    // 转换回经纬度
    const endLonLat = metersToLonLat(result.x, result.y, lon, lat)
    
    visibleBoundaries.push({
      lon: endLonLat.lon,
      lat: endLonLat.lat,
      angle: angle,
      dist: result.dist,
      blocked: result.blocked
    })
  }
  
  // 边缘平滑插值：在遮挡状态变化的地方插入中间点
  function smoothBoundaries(boundaries) {
    const smoothed = [boundaries[0]]
    
    for (let i = 1; i < boundaries.length; i++) {
      const prev = boundaries[i - 1]
      const curr = boundaries[i]
      
      // 如果遮挡状态变化了，或者距离变化超过100m，插入中间点
      const distDiff = Math.abs(curr.dist - prev.dist)
      const stateChanged = curr.blocked !== prev.blocked
      
      if (stateChanged || distDiff > 100) {
        // 插值中间点
        const midAngle = (prev.angle + curr.angle) / 2
        const midDist = (prev.dist + curr.dist) / 2
        const midBlocked = prev.blocked && curr.blocked  // 都遮挡才算遮挡
        
        // 计算中间点坐标
        const midX = Math.cos(midAngle) * midDist
        const midY = Math.sin(midAngle) * midDist
        const midLonLat = metersToLonLat(midX, midY, lon, lat)
        
        smoothed.push({
          lon: midLonLat.lon,
          lat: midLonLat.lat,
          angle: midAngle,
          dist: midDist,
          blocked: midBlocked
        })
      }
      
      smoothed.push(curr)
    }
    
    return smoothed
  }
  
  // 应用平滑（如果性能允许）
  const smoothedBoundaries = smoothBoundaries(visibleBoundaries)
  console.log(`视域边界: 原始${visibleBoundaries.length}点 → 平滑后${smoothedBoundaries.length}点`)
  
  // ==================== 步骤3：绘制视域多边形 ====================
  // 使用平滑后的边界点绘制
  const finalBoundaries = smoothedBoundaries.length >= 3 ? smoothedBoundaries : visibleBoundaries
  
  if (finalBoundaries.length >= 3) {
    // 按角度排序形成闭合多边形
    const sorted = finalBoundaries.sort((a, b) => a.angle - b.angle)
    
    // 构建多边形顶点（贴地）
    const positions = sorted.map(p => 
      Cesium.Cartesian3.fromDegrees(p.lon, p.lat, terrainHeight + 2)
    )
    
    // 创建视域多边形（深绿色贴地光斑）
    viewer.entities.add({
      polygon: {
        hierarchy: new Cesium.PolygonHierarchy(positions),
        material: Cesium.Color.fromCssColorString('#228b22').withAlpha(0.75),
        outline: true,
        outlineColor: Cesium.Color.fromCssColorString('#006400'),
        outlineWidth: 2,
        height: terrainHeight + 2,
        extrudedHeight: undefined,
        perPositionHeight: false,
        heightReference: Cesium.HeightReference.RELATIVE_TO_GROUND,
        classificationType: Cesium.ClassificationType.BOTH,
      },
      properties: {
        type: 'viewshedVisible'
      }
    })
  }
  
  console.log(`视域分析完成: 共${visibleBoundaries.length}个边界点`)
}

// 重新计算视域（高度改变时）
function recalculateViewshed() {
  if (viewshedObserverPosition && viewshedActive.value) {
    calculateViewshed(viewshedObserverPosition)
  }
}

// 处理地图点击（用于视域分析设置观察点）
function handleMapClick(movement) {
  if (!viewer || !viewshedActive.value) return
  
  const pickedPosition = viewer.scene.pickPosition(movement.position)
  if (!pickedPosition) return
  
  const cartographic = Cesium.Cartographic.fromCartesian(pickedPosition)
  const lon = Cesium.Math.toDegrees(cartographic.longitude)
  const lat = Cesium.Math.toDegrees(cartographic.latitude)
  
  viewshedObserverPosition = { lon, lat }
  calculateViewshed({ lon, lat })
}
</script>

<template>
  <div class="test-3d-page">
    <header class="page-header">
      <h2>三维测试页</h2>
      <div class="header-actions">
        <button class="action-btn" :class="{ active: heatmapVisible }" @click="toggleHeatmap">
          <span>🔥</span> 热力图
        </button>
        <button class="action-btn" :class="{ active: viewshedActive.value }" @click="toggleViewshed">
          <span>👁️</span> 视域分析
        </button>
        <button class="action-btn" @click="resetView">
          <span>🏠</span> 重置视角
        </button>
        <router-link to="/home" class="action-btn">
          <span>←</span> 返回首页
        </router-link>
      </div>
    </header>
    
    <div class="map-container">
      <div ref="mapContainer" class="cesium-container"></div>
      
      <!-- 热力图图例 -->
      <div v-if="heatmapVisible" class="heatmap-legend">
        <h4>设施密度</h4>
        <div class="heatmap-gradient"></div>
        <div class="heatmap-labels">
          <span>高</span>
          <span>低</span>
        </div>
      </div>
      
      <!-- 视域分析提示 -->
      <div v-if="viewshedActive" class="viewshed-hint">
        <span>👁️ 点击地图设置观察点</span>
      </div>
      
      <!-- 视域高度控制 -->
      <div v-if="viewshedActive" class="viewshed-control">
        <label>观察高度: {{ viewshedHeight }}m</label>
        <input 
          type="range" 
          v-model.number="viewshedHeight" 
          min="1" 
          max="100" 
          step="1"
          @input="recalculateViewshed"
        />
        <div class="height-markers">
          <span>1m</span>
          <span>50m</span>
          <span>100m</span>
        </div>
      </div>
      
      <div class="legend-panel">
        <h4>设施类型</h4>
        <div class="legend-item">
          <span class="legend-color" style="background: #ef4444;"></span>
          <span>医疗卫生</span>
        </div>
        <div class="legend-item">
          <span class="legend-color" style="background: #10b981;"></span>
          <span>教育服务</span>
        </div>
        <div class="legend-item">
          <span class="legend-color" style="background: #f59e0b;"></span>
          <span>应急避难</span>
        </div>
        <div class="legend-item">
          <span class="legend-color" style="background: #22d3ee;"></span>
          <span>居民小区</span>
        </div>
        <div class="legend-item">
          <span class="legend-color" style="background: #eab308;"></span>
          <span>商业设施</span>
        </div>
        <div class="legend-item">
          <span class="legend-color" style="background: #9333ea;"></span>
          <span>其他设施</span>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.test-3d-page {
  height: 100vh;
  display: flex;
  flex-direction: column;
  min-height: 600px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 20px;
  background: #fff;
  border-bottom: 1px solid #e5e7eb;
}

.page-header h2 {
  margin: 0;
  font-size: 20px;
  color: #1f2937;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.action-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 8px 16px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  background: #fff;
  color: #374151;
  text-decoration: none;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn:hover {
  background: #f3f4f6;
  border-color: #9ca3af;
}

.action-btn.active {
  background: #3b82f6;
  color: #fff;
  border-color: #3b82f6;
}

.map-container {
  flex: 1;
  position: relative;
  min-height: 500px;
}

.cesium-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  min-width: 800px;
  min-height: 500px;
}

.legend-panel {
  position: absolute;
  bottom: 20px;
  right: 20px;
  background: rgba(255, 255, 255, 0.95);
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  min-width: 140px;
}

.legend-panel h4 {
  margin: 0 0 10px 0;
  font-size: 14px;
  color: #1f2937;
  border-bottom: 1px solid #e5e7eb;
  padding-bottom: 8px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 8px 0;
  font-size: 13px;
  color: #4b5563;
}

.legend-color {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

/* 热力图图例 */
.heatmap-legend {
  position: absolute;
  top: 20px;
  right: 20px;
  background: rgba(255, 255, 255, 0.95);
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  min-width: 120px;
  z-index: 10;
}

.heatmap-legend h4 {
  margin: 0 0 10px 0;
  font-size: 14px;
  color: #1f2937;
  text-align: center;
}

.heatmap-gradient {
  height: 15px;
  background: linear-gradient(to right, #a50026, #ff7f00, #ffff00, #00ff00, #00bfff, #0000ff);
  border-radius: 3px;
  margin: 5px 0;
}

.heatmap-labels {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #4b5563;
}

/* 视域分析提示 */
.viewshed-hint {
  position: absolute;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(59, 130, 246, 0.95);
  color: #fff;
  padding: 10px 20px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 500;
  z-index: 10;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

/* 视域高度控制 */
.viewshed-control {
  position: absolute;
  top: 70px;
  right: 20px;
  background: rgba(255, 255, 255, 0.95);
  padding: 15px 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 10;
  min-width: 180px;
}

.viewshed-control label {
  display: block;
  font-size: 14px;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 10px;
}

.viewshed-control input[type="range"] {
  width: 100%;
  height: 6px;
  -webkit-appearance: none;
  appearance: none;
  background: #e5e7eb;
  border-radius: 3px;
  outline: none;
  cursor: pointer;
}

.viewshed-control input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 18px;
  height: 18px;
  background: #3b82f6;
  border-radius: 50%;
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.viewshed-control input[type="range"]::-moz-range-thumb {
  width: 18px;
  height: 18px;
  background: #3b82f6;
  border-radius: 50%;
  cursor: pointer;
  border: none;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.height-markers {
  display: flex;
  justify-content: space-between;
  font-size: 11px;
  color: #6b7280;
  margin-top: 5px;
}

:global(.cesium-viewer-bottom) {
  display: none !important;
}
</style>
